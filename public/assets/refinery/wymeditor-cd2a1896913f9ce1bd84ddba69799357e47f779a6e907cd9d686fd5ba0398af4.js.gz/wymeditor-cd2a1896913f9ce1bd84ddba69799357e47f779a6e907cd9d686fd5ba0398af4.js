(function() {
  window.WYMeditor = {
    INSTANCES: []
  };

  window.CKEDITOR_BASEPATH = "/assets/ckeditor/";

}).call(this);
